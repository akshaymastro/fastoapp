export default actionTypes = {
  NETWORK_REACHABILITY: "NETWORK_REACHABILITY"
};
