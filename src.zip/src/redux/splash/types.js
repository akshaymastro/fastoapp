export default actionTypes = {
  FETCH_TRANSLATION: 'FETCH_TRANSLATION', // if needed
};
