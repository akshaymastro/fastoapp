const apiKey = 'AIzaSyCdX116ggJ_oadelay7Q5Sqme72S046Ch8';

module.exports = apiKey