export const GET_VEHICLE = "GET_VEHICLE";
export const GET_CATEGORY = "GET_CATEGORY";
export const SET_RIDE_VALUE = "SET_RIDE_VALUE";
export const SET_SELECTED_RIDE = "SET_SELECTED_RIDE";
export const NEW_RIDE = "NEW_RIDE";
export const CURRENT_RIDE = "CURRENT_RIDE";