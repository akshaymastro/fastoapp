const baseUrl = "http://192.168.43.75:4000";

module.exports = baseUrl;