/* eslint-disable global-require */

const images = {
    Clear: require('./background.png'),
  };
  
  export default images;
  