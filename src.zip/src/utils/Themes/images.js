const AppImages = {
  //   exmpale: require("../../assets/exmaple.png"),
  /**
   * Exmpale To import centric module images
   */
};
export default AppImages;
