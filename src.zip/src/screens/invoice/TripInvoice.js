import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const TripInvoice = () => {
    return (
        <View>
            <Text>Trip Invoice</Text>
        </View>
    )
}

export default TripInvoice;

const styles = StyleSheet.create({})
