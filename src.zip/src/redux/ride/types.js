export const GET_FARE = "GET_FARE";
