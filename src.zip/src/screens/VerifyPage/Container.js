// import React from 'react';
// import {connect} from 'react-redux';
// import PhoneVerify from './PhoneVerify';
// // import { loginApiPhoneCheck, skipLogin, verifyOtpApi } from '../../../action/actionCreator/loginApiPhoneCheck';
// import {bindActionCreators} from 'redux';
// import {verifyOtpHandler} from '../../redux/auth/actions';

// export class PhoneVerifyContainer extends React.Component {
//   constructor(props) {
//     super(props);
//   }
//   render() {
//     return <PhoneVerify {...this.props} />;
//   }
// }
